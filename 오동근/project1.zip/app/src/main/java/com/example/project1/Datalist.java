package com.example.project1;

public class Datalist {
    String mName;
    String mNumber;
    String mDepartment;
}
